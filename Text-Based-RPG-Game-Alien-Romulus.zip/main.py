import random
import json
import os

# Define item types including rare items
common_items = ["flare gun", "medkit", "rations", "plasma rifle", "grenade"]
rare_items = ["alien artifact", "pulse cannon", "xenomorph venom", "experimental suit"]

# Define clues for rare items
clues = {
    "alien artifact": "You hear rumors about an alien artifact hidden in a laboratory.",
    "pulse cannon": "A maintenance log mentions an old pulse cannon stored in the control room.",
    "xenomorph venom": "An old research note hints at xenomorph venom in the storage room.",
    "experimental suit": "A security report indicates an experimental suit was last seen in the lab."
}

xenomorphs = {
    "facehugger": {"health": 1, "damage": 2},
    "warrior": {"health": 3, "damage": 5},
    "queen": {"health": 10, "damage": 8}
}

levels = {
    1: "You are in the lower decks of the Romulus. The area is dark and filled with machinery.",
    2: "You have moved to the middle levels. This area is where the crew's quarters and mess hall are located.",
    3: "You reach the upper levels. This area contains the control center and escape pods."
}

player = {
    "health": 10,
    "inventory": [],
    "level": 1,
    "xp": 0,
    "xp_to_level": 10,
    "damage": 1,
    "speed": 1
}

def save_game():
    with open('savegame.json', 'w') as file:
        json.dump(player, file)
    print("Game saved successfully.")

def load_game():
    if os.path.exists('savegame.json'):
        with open('savegame.json', 'r') as file:
            global player
            player = json.load(file)
        print("Game loaded successfully.")
    else:
        print("No saved game found. Starting a new game.")

def introduction():
    print("Welcome to the Alien: Romulus Text-Based RPG!")
    print("You are a crew member on the spaceship Romulus.")
    print("The ship has encountered an alien threat.")
    print("Your goal is to survive and escape the ship.")
    print("Be careful, as your choices will determine your fate.")
    print("")

def choose_path():
    print(f"You are on Level {player['level']}. {levels[player['level']]}")
    print("You can either go to the left corridor or the right corridor.")
    choice = input("Which direction do you choose? (Left / Right): ").lower()

    if choice == "left":
        left_corridor()
    elif choice == "right":
        right_corridor()
    else:
        print("Invalid choice. Please choose 'Left' or 'Right'.")
        choose_path()

def left_corridor():
    print("You enter a dimly lit corridor. You see a door to the Storage Room and another to the Security Room.")
    choice = input("Which door do you choose? (Storage Room / Security Room): ").lower()

    if choice == "storage room":
        storage_room()
    elif choice == "security room":
        security_room()
    else:
        print("Invalid choice. Please choose 'Storage Room' or 'Security Room'.")
        left_corridor()

def right_corridor():
    print("You enter a well-lit corridor. You see doors leading to the Laboratory and the Control Room.")
    choice = input("Which door do you choose? (Laboratory / Control Room): ").lower()

    if choice == "laboratory":
        laboratory()
    elif choice == "control room":
        control_room()
    else:
        print("Invalid choice. Please choose 'Laboratory' or 'Control Room'.")
        right_corridor()

def storage_room():
    print("You enter the Storage Room. It’s cluttered with boxes and equipment.")
    if random.random() < 0.2:
        item = random.choice(rare_items)
        print(f"You find a rare item: {item}.")
        player["inventory"].append(item)
    else:
        print("You find some common items.")
        item = random.choice(common_items)
        player["inventory"].append(item)
    print(f"Current inventory: {player['inventory']}")
    print("You notice a note mentioning xenomorph venom hidden elsewhere in the ship.")
    upgrade_weapon()
    choose_path()

def security_room():
    print("You enter the Security Room. It is heavily fortified but appears abandoned.")
    print("You find a security terminal with logs about Xenomorph sightings.")
    print("You can either read the logs or try to access the security systems.")
    choice = input("What do you want to do? (Read Logs / Access Systems): ").lower()

    if choice == "read logs":
        print("The logs reveal detailed information about Xenomorph types and weaknesses.")
        print("You gain valuable knowledge about how to handle different Xenomorphs.")
        print("The logs also mention a pulse cannon stored in the control room.")
        choose_path()
    elif choice == "access systems":
        if random.random() < 0.5:
            print("You successfully access the systems and unlock some useful data. You gain a boost in health.")
            player["health"] += 5
            print(f"Your current health: {player['health']}")
            choose_path()
        else:
            print("The system access fails and triggers an alarm. Xenomorphs are alerted!")
            encounter_xenomorph()
    else:
        print("Invalid choice. Please choose 'Read Logs' or 'Access Systems'.")
        security_room()

def laboratory():
    print("You enter the Laboratory. It’s filled with scientific equipment and research data.")
    print("You can either search for useful equipment or examine the research data.")
    choice = input("What do you want to do? (Search Equipment / Examine Data): ").lower()

    if choice == "search equipment":
        if random.random() < 0.1:
            item = random.choice(rare_items)
            print(f"You find a rare item: {item}.")
            player["inventory"].append(item)
        else:
            item = random.choice(common_items)
            print(f"You find a {item}.")
            player["inventory"].append(item)
        print(f"Current inventory: {player['inventory']}")
        print("You come across a research note mentioning an experimental suit.")
        upgrade_weapon()
        choose_path()
    elif choice == "examine data":
        print("The research data provides insights into the Xenomorph life cycle.")
        print("You learn that using grenades can be particularly effective against them.")
        choose_path()
    else:
        print("Invalid choice. Please choose 'Search Equipment' or 'Examine Data'.")
        laboratory()

def control_room():
    print("You enter the Control Room. The monitors are flickering, and the control panels are damaged.")
    print("You need to fix the control panels to restore communication and control.")
    if random.random() < 0.5:
        print("You manage to repair the panels and establish communication. Help is on the way!")
        print("You have survived this encounter!")
        if player["level"] < 3:
            player["level"] += 1
            player["xp_to_level"] += 10
            print(f"Moving to Level {player['level']}.")
            choose_path()
        else:
            ending_1()
    else:
        print("You are unable to fix the panels. The alien attacks and you meet a grim fate.")
        game_over()

def encounter_xenomorph():
    xenomorph = random.choice(list(xenomorphs.keys()))
    print(f"You encounter a {xenomorph}!")
    combat(xenomorph)

def combat(xenomorph):
    print(f"You are facing a {xenomorph}.")
    while xenomorphs[xenomorph]["health"] > 0 and player["health"] > 0:
        action = input("Do you want to (Attack / Evade): ").lower()
        if action == "attack":
            weapon_damage = player["damage"]
            if "plasma rifle" in player["inventory"]:
                print("You use the plasma rifle to attack the Xenomorph!")
                weapon_damage += 15
                player["inventory"].remove("plasma rifle")
            elif "grenade" in player["inventory"]:
                print("You use a grenade to attack the Xenomorph!")
                weapon_damage += 20
                player["inventory"].remove("grenade")
            elif "pulse cannon" in player["inventory"]:
                print("You use the pulse cannon to attack the Xenomorph!")
                weapon_damage += 25
                player["inventory"].remove("pulse cannon")
            elif "xenomorph venom" in player["inventory"]:
                print("You use xenomorph venom to attack the Xenomorph!")
                weapon_damage += 30
                player["inventory"].remove("xenomorph venom")
            elif "experimental suit" in player["inventory"]:
                print("You use the experimental suit to attack the Xenomorph!")
                weapon_damage += 35
                player["inventory"].remove("experimental suit")
            xenomorphs[xenomorph]["health"] -= weapon_damage
            print(f"You dealt {weapon_damage} damage to the {xenomorph}.")
            if xenomorphs[xenomorph]["health"] <= 0:
                print(f"You have defeated the {xenomorph}!")
                gain_xp(10)
                choose_path()
            else:
                print(f"The {xenomorph} is still alive. It attacks you!")
                player["health"] -= xenomorphs[xenomorph]["damage"]
                print(f"You received {xenomorphs[xenomorph]['damage']} damage. Your current health: {player['health']}")
        elif action == "evade":
            if random.random() < 0.5 * player["speed"]:
                print("You successfully evade the Xenomorph and escape!")
                choose_path()
            else:
                print("You fail to evade the Xenomorph and it attacks you!")
                player["health"] -= xenomorphs[xenomorph]["damage"]
                print(f"You received {xenomorphs[xenomorph]['damage']} damage. Your current health: {player['health']}")
        else:
            print("Invalid choice. Please choose 'Attack' or 'Evade'.")

    if player["health"] <= 0:
        game_over()

def gain_xp(amount):
    player["xp"] += amount
    print(f"You gained {amount} XP.")
    if player["xp"] >= player["xp_to_level"]:
        level_up()

def level_up():
    player["level"] += 1
    player["xp"] -= player["xp_to_level"]
    player["xp_to_level"] += 10
    player["damage"] += 2
    player["speed"] += 0.5
    print(f"Congratulations! You've leveled up to Level {player['level']}!")
    print(f"Your damage is now {player['damage']}, and your speed is now {player['speed']}.")

def upgrade_weapon():
    print("Would you like to upgrade your weapons? (Yes / No)")
    choice = input().lower()
    if choice == "yes":
        if "plasma rifle" in player["inventory"]:
            print("Upgrading plasma rifle...")
            print("Your plasma rifle is now more powerful!")
        elif "pulse cannon" in player["inventory"]:
            print("Upgrading pulse cannon...")
            print("Your pulse cannon is now more powerful!")
        elif "xenomorph venom" in player["inventory"]:
            print("Upgrading xenomorph venom...")
            print("Your xenomorph venom is now more effective!")
        elif "experimental suit" in player["inventory"]:
            print("Upgrading experimental suit...")
            print("Your experimental suit is now more advanced!")
        else:
            print("You don't have any weapons to upgrade.")
    elif choice == "no":
        print("Continuing without upgrades.")
    else:
        print("Invalid choice. Please choose 'Yes' or 'No'.")
        upgrade_weapon()

def trap_or_puzzle():
    print("You encounter a trap or puzzle!")
    if random.random() < 0.5:
        print("A trap is activated! You need to find a way to disarm it.")
        if "medkit" in player["inventory"]:
            print("You use the medkit to carefully navigate the trap.")
            player["inventory"].remove("medkit")
            print("You successfully avoid the trap.")
        else:
            print("You don't have the right equipment to disarm the trap. You take some damage.")
            player["health"] -= 5
            print(f"Your current health: {player['health']}")
    else:
        print("You find a puzzle that you need to solve.")
        if random.random() < 0.7:
            print("You solve the puzzle and find some valuable items!")
            if random.random() < 0.2:
                item = random.choice(rare_items)
                player["inventory"].append(item)
                print(f"You found a rare item: {item}.")
                print(f"Hint: Clue about this item - {clues[item]}")
            else:
                item = random.choice(common_items)
                player["inventory"].append(item)
                print(f"You found a {item}.")
        else:
            print("You fail to solve the puzzle and lose some time.")
            player["health"] -= 2
            print(f"Your current health: {player['health']}")
    choose_path()

def ending_1():
    print("Congratulations! You've reached the final level and escaped the Romulus.")
    print("Your bravery and quick thinking have saved you and possibly others.")
    game_over()

def game_over():
    print("Game Over. You didn't survive the encounter.")
    play_again = input("Would you like to play again? (yes / no): ").lower()
    if play_again == "yes":
        player["health"] = 10
        player["inventory"] = []
        player["level"] = 1
        player["xp"] = 0
        player["xp_to_level"] = 10
        player["damage"] = 1
        player["speed"] = 1
        introduction()
        choose_path()
    else:
        print("Thank you for playing. Goodbye!")

# Main game loop
if __name__ == "__main__":
    print("Do you want to (Start a new game / Load saved game)?")
    choice = input().lower()
    if choice == "load saved game":
        load_game()
    else:
        introduction()
    choose_path()
